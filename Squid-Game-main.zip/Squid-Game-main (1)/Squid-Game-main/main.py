import subprocess
import tkinter
from tkinter import *
from tkinter import ttk
import time
import playsound
from playsound import playsound
import threading
import os




age = input("Enter your age : ")
if(int(age)>=18):

    root = Tk()
    root.title("SQUID GAME")
    root.geometry("1530x1080")
    def play():
        time.sleep(8)
        playsound('instructions.mp3')
        time.sleep(2)
        os.system('python redlightgreen.py')

     
    # making a button which trigger the function so sound can be played
    play_button = Button(root, text="PLAYING INSTRUCTIONS IN 10SECS", font=("Helvetica", 32),
                         relief=GROOVE, command=threading.Thread(target=play).start())
    play_button.pack(pady=20)

     
    info=Label(root,text="PLEASE LISTEN TO THE INSTRUCTIONS CAREFULLY BEFORE PRESSING THE START BUTTON ",
               font=("times new roman",10,"bold")).pack(pady=20)


    bg = PhotoImage(file="squid6.png")
    canvas1=Canvas(root, width =1530,height=1080)
    canvas1.pack(fill="both",expand=True)
    canvas1.create_image(0,0,image=bg,anchor = "nw")
    ##
    ##labelimage = Label(
    ##    root,
    ##    image = img1,
    ##    background = "#ffffff",
    ##)
    ##labelimage.pack(pady=(40,0))
    img= PhotoImage(file="squid.png")
    label= ttk.Label(root,image = img)


    ##root = Tk()
    ##root.configure(background='grey')
    ##root.geometry('700x400')
    ####root.configure(background="#ffffff")
    ##
    ##
    ##bgimg=PhotoImage(file='png-clipart-background-music-musical-background-music-illustration-poster-colors.png')
    ##label=Label(root,image=bgimg)
    ##label.place(x=0,y=0)
    w2 = Label(root, justify=LEFT, text="Squid Game - 1")
    w2.config(font=("times", 34))
    w2.place(x=50,y=50)

    w3 = Label(root, justify=LEFT, text='''A Real Life
    Depiction''')
    w3.config(font=("times", 34))
    w3.place(x=1190,y=30)





    def sym():
        subprocess.call(['python','D:\Final project\Squid-Game-main (1)\Squid-Game-main\redlightgreen.py'])

    root = tkinter.Toplevel()

    img2 = PhotoImage(file="Frame.png")

    btnStart = Button(
        root,
        image=img2,
        relief=FLAT,
        border=0,
        command=sym,
    )

    btnStart.pack()

    root.mainloop()

else:
    
    
    print("Your Not Eligible ")

