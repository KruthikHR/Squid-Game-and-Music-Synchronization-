import tensorflow as tf
import tensorflow_hub as hub
import cv2
import numpy as np
import time
from playsound import playsound

gpus = tf.config.experimental.list_physical_devices('GPU')
for gpu in gpus:
    tf.config.experimental.set_memory_growth(gpu, True)

model = hub.load('https://tfhub.dev/google/movenet/multipose/lightning/1')
movenet = model.signatures['serving_default']

EDGES = {
    (0, 1): 'm',
    (0, 2): 'c',
    (1, 3): 'm',
    (2, 4): 'c',
    (0, 5): 'm',
    (0, 6): 'c',
    (5, 7): 'm',
    (7, 9): 'm',
    (6, 8): 'c',
    (8, 10): 'c',
    (5, 6): 'y',
    (5, 11): 'm',
    (6, 12): 'c',
    (11, 12): 'y',
    (11, 13): 'm',
    (13, 15): 'm',
    (12, 14): 'c',
    (14, 16): 'c'
}

def loop_through_people(frame, keypoints_with_scores, edges, confidence_threshold):
    for person in keypoints_with_scores:
        draw_connections(frame, person, edges, confidence_threshold)
        draw_keypoints(frame, person, confidence_threshold)

def draw_keypoints(frame, keypoints, confidence_threshold):
    y, x, c = frame.shape
    shaped = np.squeeze(np.multiply(keypoints, [y,x,1]))

    for kp in shaped:
        ky, kx, kp_conf = kp
        if kp_conf > confidence_threshold:
            cv2.circle(frame, (int(kx), int(ky)), 6, (0,255,0), -1)

def draw_connections(frame, keypoints, edges, confidence_threshold):
    y, x, c = frame.shape
    shaped = np.squeeze(np.multiply(keypoints, [y,x,1]))

    for edge, color in edges.items():
        p1, p2 = edge
        y1, x1, c1 = shaped[p1]
        y2, x2, c2 = shaped[p2]

        if (c1 > confidence_threshold) & (c2 > confidence_threshold):      
            if c1 > 0.7 and c2 > 0.7:
                cv2.line(frame, (int(x1), int(y1)), (int(x2), int(y2)), (0,255,0), 4)  # Green lines for still person
            else:
                cv2.line(frame, (int(x1), int(y1)), (int(x2), int(y2)), (0,0,255), 4)  # Red lines for moving person
            
cap = cv2.VideoCapture(0)

num_players = 2  # Set the number of players

player_scores = [0] * num_players
player_eliminated = [False] * num_players
player_start_time = [0] * num_players

game_started = False

while cap.isOpened():
    ret, frame = cap.read()
    
    # Resize image
    img = frame.copy()
    img = tf.image.resize_with_pad(tf.expand_dims(img, axis=0), 384, 640)
    input_img = tf.cast(img, dtype=tf.int32)
    
    # Detection section
    results = movenet(input_img)
    keypoints_with_scores = results['output_0'].numpy()[:,:,:51].reshape((-1, 17, 3))
    
    # Render keypoints 
    for person in keypoints_with_scores:
        draw_connections(frame, person, EDGES, 0.1)
        draw_keypoints(frame, person, 0.1)
    
    if not game_started:
        if len(keypoints_with_scores) >= 2:
            person1 = keypoints_with_scores[0]
            person2 = keypoints_with_scores[1]
            
            if person1[11][2] > 0.7 and person1[12][2] > 0.7 and person2[11][2] > 0.7 and person2[12][2] > 0.7:
                game_started = True

    if game_started:
        # Calculate winner or eliminate players based on movement
        if len(keypoints_with_scores) >= 2:
            person1 = keypoints_with_scores[0]
            person2 = keypoints_with_scores[1]
            
            if player_start_time[0] == 0:
                if person1[11][2] > 0.7 and person1[12][2] > 0.7:
                    player_start_time[0] = time.time()
                    playsound('greenLight.mp3')
                    green_light_image = cv2.imread('im1.png')
                    cv2.imshow("Green Light", green_light_image)
                    cv2.waitKey(4000)
                    cv2.destroyWindow("Green Light")

            if player_start_time[1] == 0:
                if person2[11][2] > 0.7 and person2[12][2] > 0.7:
                    player_start_time[1] = time.time()                                

            elapsed_time1 = time.time() - player_start_time[0]
            elapsed_time2 = time.time() - player_start_time[1]
            
            if elapsed_time1 >= 8:
                playsound('redLight.mp3')
                
                if elapsed_time1 >= 8:
                    playsound('redLight.mp3')
                    red_light_image = cv2.imread('im2.png')
                    cv2.imshow("Red Light", red_light_image)
                    cv2.waitKey(2000)
                    cv2.destroyWindow("Red Light")
                    if elapsed_time1 >= 13:
                        eliminated_frame = np.copy(frame)
                        cv2.putText(eliminated_frame, "Person 1 is eliminated",  (25, 200), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (255, 0, 255), 4)
                        cv2.imshow("Eliminated", eliminated_frame)
                        playsound('gunshots.mp3')

                        winner_frame = np.copy(frame)
                        cv2.putText(winner_frame, "Person 2 is the winner",  (25, 200), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (255, 0, 0), 4)
                        cv2.imshow("Winner", winner_frame)

                        player_eliminated[0] = True
                        break

                if elapsed_time2 >= 8:
                    if elapsed_time1 >= 13:
                        eliminated_frame = np.copy(frame)
                        cv2.putText(eliminated_frame, "Person 2 is eliminated", (50, 200), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (255, 0, 255), 4)
                        cv2.imshow("Eliminated", eliminated_frame)
                        playsound('gunshots.mp3')

                        winner_frame = np.copy(frame)
                        cv2.putText(winner_frame, "Person 1 is the winner", (50, 200), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (255, 0, 0), 4)
                        cv2.imshow("Winner", winner_frame)

                        player_eliminated[1] = True
                        break

                    
    cv2.imshow('Main Window', frame)
    
    if cv2.waitKey(1) &0xFF == ord('q'):
        break

cv2.waitKey(0)
cv2.destroyAllWindows()
cap.release()